import UIKit

class Carfeatures {
    var BodyColor : String = "Pink"
    
    var InteriorMaterial : String = "Leather"
    
    var EngineType : String = "V5 Engine"
    
    var MPH : String = "120 HorsePower"
}


